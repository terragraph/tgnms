# TODO(akshayka): This is a hack; the swig-auto-generated cvxcore.py
# tries to import cvxcore as `from . import _cvxcore`
import _cvxcore
