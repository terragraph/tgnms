Use this


```
digraph G {Hello->World}
```

to get

```graphviz
digraph G {Hello->World}
```

with with Äüö

```graphviz
digraph G {Hello->World with Äüö}
```

See [(this is a link to whatever)](#whatever) for an example with options `{.graphviz #whatever caption="this is the caption" width=35%}`:

```{.graphviz #whatever caption="this is the caption" width=35%}
digraph G {Hello->World}
```
