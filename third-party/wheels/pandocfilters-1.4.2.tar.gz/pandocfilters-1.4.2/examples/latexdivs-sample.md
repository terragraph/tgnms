\newcommand{\eqn}{\nabla \times \mathbf{E} = - \frac{\partial \mathbf{B}}{\partial t}}

<div latex="true" abc="test" class="proof">
Turned into a proof environment.

$$\eqn$$
</div>

<div latex="true" abc="test" class="case test">
First class is picked and converted into a LaTeX environment.

$$\eqn$$
</div>

<div class="totally nonsense" latex="false">
Shouldn't be converted into LaTeX environments. Since LaTeX is false.
</div>

<div class="totally nonsense">
Also shouldn't be converted into LaTeX environments. Since LaTeX is not present.
</div>
