---
header-includes:

    - \usepackage{libertine}
    - \usepackage[autocompile]{gregoriotex}

---


Use this

~~~~~~
```gabc
(c4) A(f)ve(c) Ma(d)rí(dh'!iv)a.(h.) (::)
```
~~~~~~

to get

```gabc
(c4) A(f)ve(c) Ma(d)rí(dh'!iv)a.(h.) (::)
```

and this

~~~~~~
`gabc-score`{.gabc staffsize=12 annotation=Off. mode=2.}
~~~~~~

to get the score in `gabc-score.gabc` :

`gabc-score`{.gabc staffsize=12 annotation=Off. mode=2.}
