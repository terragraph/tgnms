#include "glbopts.h"

const char *SCS(version)(void) { return SCS_VERSION; }
