:orphan:

boilerplate
===========

Most Python files should include the following boilerplate:

.. code-block:: python

    from __future__ import (absolute_import, division, print_function)
    __metaclass__ = type
